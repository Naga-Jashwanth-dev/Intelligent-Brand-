import { and, desc, eq } from "drizzle-orm"
import mammoth from "mammoth"
import { NextResponse } from "next/server"
import { z } from "zod"
import { requireAuthenticatedUser } from "@/lib/auth-session"
import { db } from "@/lib/db"
import { reviewContent } from "@/lib/review-engine"
import { brandReviews, brandSources, reviewEvents } from "@/lib/schema"
import { serializeReview, serializeSource } from "@/lib/workspace-data"
import type { ReviewAttachment } from "@/lib/types"

export const runtime = "nodejs"
export const maxDuration = 90

const reviewInputSchema = z.object({
  title: z.string().trim().min(3).max(120),
  channel: z.string().trim().min(2).max(48),
  draft: z.string().trim().min(8).max(20000),
  reviewId: z.string().trim().max(160).optional(),
})

const supportedTypes: Record<string, { mediaType: string; kind: ReviewAttachment["kind"] }> = {
  pdf: { mediaType: "application/pdf", kind: "pdf" },
  docx: {
    mediaType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    kind: "document",
  },
  txt: { mediaType: "text/plain", kind: "text" },
  md: { mediaType: "text/markdown", kind: "text" },
  png: { mediaType: "image/png", kind: "image" },
  jpg: { mediaType: "image/jpeg", kind: "image" },
  jpeg: { mediaType: "image/jpeg", kind: "image" },
  webp: { mediaType: "image/webp", kind: "image" },
}

function sanitizeFilename(filename: string) {
  return filename.replace(/[\\/\u0000-\u001f]/g, "").slice(0, 160) || "attachment"
}

export async function POST(request: Request) {
  try {
    const user = await requireAuthenticatedUser()
    const contentLength = Number(request.headers.get("content-length") ?? 0)
    if (contentLength > 8_500_000) {
      return NextResponse.json({ error: "Attachments must be smaller than 8 MB." }, { status: 413 })
    }

    const formData = await request.formData()
    const parsedInput = reviewInputSchema.safeParse({
      title: formData.get("title"),
      channel: formData.get("channel"),
      draft: formData.get("draft"),
      reviewId: formData.get("reviewId") || undefined,
    })

    if (!parsedInput.success) {
      return NextResponse.json({ error: "Add a title, channel, and draft of at least 8 characters." }, { status: 400 })
    }

    const { title, channel, draft, reviewId } = parsedInput.data
    if (reviewId) {
      const [ownedReview] = await db
        .select({ id: brandReviews.id })
        .from(brandReviews)
        .where(and(eq(brandReviews.id, reviewId), eq(brandReviews.userId, user.id)))
        .limit(1)
      if (!ownedReview) {
        return NextResponse.json({ error: "Review not found." }, { status: 404 })
      }
    }

    const uploadedValue = formData.get("attachment")
    const file = typeof File !== "undefined" && uploadedValue instanceof File && uploadedValue.size > 0
      ? uploadedValue
      : null
    let attachment: ReviewAttachment | null = null
    let attachmentBytes: Uint8Array | null = null
    let extractedText = ""

    if (file) {
      if (file.size > 8 * 1024 * 1024) {
        return NextResponse.json({ error: "Attachments must be smaller than 8 MB." }, { status: 413 })
      }
      const extension = file.name.split(".").pop()?.toLowerCase() ?? ""
      const fileType = supportedTypes[extension]
      if (!fileType) {
        return NextResponse.json({ error: "Use a PDF, DOCX, TXT, Markdown, PNG, JPG, or WEBP file." }, { status: 400 })
      }

      attachmentBytes = new Uint8Array(await file.arrayBuffer())
      const altText = String(formData.get("altText") ?? "").trim().slice(0, 400)
      attachment = {
        name: sanitizeFilename(file.name),
        kind: fileType.kind,
        mediaType: fileType.mediaType,
        size: file.size,
        altText,
      }

      if (extension === "txt" || extension === "md") {
        extractedText = new TextDecoder("utf-8", { fatal: false }).decode(attachmentBytes).slice(0, 12000)
      } else if (extension === "docx") {
        try {
          const extracted = await mammoth.extractRawText({ buffer: Buffer.from(attachmentBytes) })
          extractedText = extracted.value.slice(0, 12000)
        } catch {
          return NextResponse.json({ error: "We couldn't read that DOCX file. Try exporting it as a PDF or plain text." }, { status: 400 })
        }
      }
    }

    const sourceRows = await db
      .select()
      .from(brandSources)
      .where(and(eq(brandSources.userId, user.id), eq(brandSources.status, "approved")))
      .orderBy(desc(brandSources.updatedAt))
      .limit(32)
    const sources = sourceRows.map(serializeSource)
    const result = await reviewContent({
      title,
      channel,
      draft,
      sources,
      attachment,
      attachmentBytes,
      extractedText,
    })

    const savedRow = await db.transaction(async (tx) => {
      const now = new Date()
      let row: typeof brandReviews.$inferSelect | undefined

      if (reviewId) {
        const [updated] = await tx
          .update(brandReviews)
          .set({
            title,
            channel,
            draft,
            status: result.status,
            score: result.score,
            summary: result.summary,
            findings: result.findings,
            attachment: attachment ?? {},
            updatedAt: now,
          })
          .where(and(eq(brandReviews.id, reviewId), eq(brandReviews.userId, user.id)))
          .returning()
        row = updated
      } else {
        const [created] = await tx
          .insert(brandReviews)
          .values({
            id: crypto.randomUUID(),
            userId: user.id,
            title,
            channel,
            draft,
            status: result.status,
            score: result.score,
            summary: result.summary,
            findings: result.findings,
            attachment: attachment ?? {},
            createdAt: now,
            updatedAt: now,
          })
          .returning()
        row = created
      }

      if (!row) throw new Error("Review write failed")

      await tx.insert(reviewEvents).values({
        id: crypto.randomUUID(),
        userId: user.id,
        reviewId: row.id,
        event: reviewId ? "review_rechecked" : "review_created",
        actor: user.name || user.email,
        details: {
          score: result.score,
          issueCount: result.findings.filter((finding) => finding.severity !== "pass").length,
          engine: result.engine,
        },
        createdAt: now,
      })

      return row
    })

    return NextResponse.json({ review: serializeReview(savedRow), engine: result.engine })
  } catch (error) {
    if (error instanceof Error && error.message === "Unauthorized") {
      return NextResponse.json({ error: "Sign in to review content." }, { status: 401 })
    }
    const errorName = error instanceof Error ? error.name : "UnknownError"
    console.error("[v0] Review request failed:", errorName)
    return NextResponse.json({ error: "We couldn't complete the review. Please try again." }, { status: 500 })
  }
}

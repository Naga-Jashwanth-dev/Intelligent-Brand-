import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { AuthForm } from "@/components/auth-form"
import { auth } from "@/lib/auth"

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect("/")

  const demoCredentials = {
    email: "brandguard-demo@example.com",
    password: "Garden-Review-2026!",
  }

  return <AuthForm mode="sign-in" demoCredentials={demoCredentials} />
}

import { redirect } from "next/navigation"
import { headers } from "next/headers"
import { BrandGuardApp } from "@/components/brand-guard-app"
import { auth } from "@/lib/auth"
import { getWorkspaceData } from "@/lib/workspace-data"

export default async function HomePage() {
  const session = await auth.api.getSession({ headers: await headers() })

  if (!session?.user) {
    redirect("/sign-in")
  }

  const initialData = await getWorkspaceData(session.user.id)

  return (
    <BrandGuardApp
      currentUser={{
        name: session.user.name,
        email: session.user.email,
      }}
      initialData={initialData}
    />
  )
}

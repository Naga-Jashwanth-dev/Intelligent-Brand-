import { sql } from "drizzle-orm"
import {
  boolean,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core"
import type {
  ReviewAttachment,
  ReviewFinding,
  ReviewStatus,
  SourceKind,
  SourceStatus,
} from "@/lib/types"

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  userId: text("userId")
    .notNull()
    .references(() => user.id, { onDelete: "cascade" }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const brandSources = pgTable("brand_sources", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  kind: text("kind").$type<SourceKind>().notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  status: text("status").$type<SourceStatus>().notNull().default("draft"),
  sourceLabel: text("sourceLabel"),
  sourceUrl: text("sourceUrl"),
  metadata: jsonb("metadata")
    .$type<Record<string, unknown>>()
    .notNull()
    .default(sql`'{}'::jsonb`),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const brandReviews = pgTable("brand_reviews", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  title: text("title").notNull(),
  channel: text("channel").notNull(),
  draft: text("draft").notNull(),
  status: text("status").$type<ReviewStatus>().notNull().default("needs_review"),
  score: integer("score").notNull().default(0),
  summary: text("summary").notNull().default(""),
  findings: jsonb("findings")
    .$type<ReviewFinding[]>()
    .notNull()
    .default(sql`'[]'::jsonb`),
  attachment: jsonb("attachment")
    .$type<ReviewAttachment | Record<string, never>>()
    .notNull()
    .default(sql`'{}'::jsonb`),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const reviewEvents = pgTable("review_events", {
  id: text("id").primaryKey(),
  userId: text("userId").notNull(),
  reviewId: text("reviewId").notNull(),
  event: text("event").notNull(),
  actor: text("actor").notNull(),
  details: jsonb("details")
    .$type<Record<string, unknown>>()
    .notNull()
    .default(sql`'{}'::jsonb`),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
})

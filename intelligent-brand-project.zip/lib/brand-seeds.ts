import type { ReviewFinding, SourceKind } from "@/lib/types"

export interface SeedBrandSource {
  id: string
  userId: string
  kind: SourceKind
  title: string
  body: string
  status: "approved"
  sourceLabel: string
  sourceUrl: null
  metadata: Record<string, unknown>
}

export function createDemoSources(userId: string): SeedBrandSource[] {
  const source = (
    key: string,
    kind: SourceKind,
    title: string,
    body: string,
    metadata: Record<string, unknown> = {},
  ): SeedBrandSource => ({
    id: `${userId}:seed:${key}`,
    userId,
    kind,
    title,
    body,
    status: "approved",
    sourceLabel: "Meridian brand handbook · 2026",
    sourceUrl: null,
    metadata: { demo: true, ...metadata },
  })

  return [
    source(
      "voice",
      "guideline",
      "Voice & tone",
      "Be confident, clear, and helpful. Lead with concrete benefits. Avoid absolute claims such as “fastest,” “best,” “most secure,” or “guaranteed” unless exact wording is supported by an approved fact. Keep calls to action direct and human.",
      { sections: ["Voice", "Tone", "Calls to action"] },
    ),
    source(
      "performance",
      "fact",
      "Performance benchmark",
      "In internal Q2 2026 tests, Meridian generated reports 32% faster than Meridian v4 across the standard content-review benchmark. This is a controlled internal benchmark, not an industry-wide comparison.",
      { claim: "32% faster", qualifier: "internal Q2 2026 tests" },
    ),
    source(
      "security",
      "fact",
      "Approved security statement",
      "Meridian is SOC 2 Type II audited. Customer content is encrypted at rest with AES-256 and in transit with TLS 1.2 or higher.",
      { approvedPhrases: ["SOC 2 Type II audited", "AES-256", "TLS 1.2 or higher"] },
    ),
    source(
      "terminology",
      "terminology",
      "Product terminology",
      "Use “workspace” instead of “account” when referring to the product space. Use “team member” instead of “user” when referring to a person. Describe recommendations as “AI-assisted,” not “AI magic.” Keep Meridian in title case.",
      {
        preferredTerms: { account: "workspace", user: "team member", "AI magic": "AI-assisted" },
      },
    ),
    source(
      "assets",
      "asset",
      "Approved brand assets",
      "Current assets: Meridian wordmark v3 in evergreen or white, and Meridian symbol v3. Retired: wordmark v2. Do not stretch, recolor, or place approved marks on low-contrast backgrounds. Add descriptive alt text to meaningful imagery; use empty alt text only for decorative imagery.",
      {
        approvedAssets: ["Meridian wordmark v3", "Meridian symbol v3"],
        retiredAssets: ["Meridian wordmark v2"],
      },
    ),
    source(
      "accessibility",
      "guideline",
      "Accessibility checklist",
      "Use descriptive alt text for meaningful images, maintain readable contrast, and write link text that explains its destination. Do not rely on color alone to communicate status.",
      { sections: ["Images", "Contrast", "Links", "Status"] },
    ),
  ]
}

export function createDemoReview(userId: string) {
  const sourceId = (key: string) => `${userId}:seed:${key}`
  const findings: ReviewFinding[] = [
    {
      id: `${userId}:seed:finding-fastest`,
      severity: "high",
      category: "Claims",
      title: "Unsupported performance superlative",
      excerpt: "the fastest",
      explanation:
        "The approved benchmark supports a scoped comparison—32% faster than Meridian v4 in internal Q2 2026 tests—not an unqualified “fastest” claim.",
      recommendation: "Replace the absolute claim with the qualified benchmark and keep its test context.",
      originalText: "is the fastest",
      suggestedText: "generated reports 32% faster than Meridian v4 in internal Q2 2026 tests",
      sourceId: sourceId("performance"),
      sourceTitle: "Performance benchmark",
      sourceLabel: "Meridian brand handbook · 2026",
      confidence: 0.98,
    },
    {
      id: `${userId}:seed:finding-security`,
      severity: "medium",
      category: "Security wording",
      title: "Security wording needs approved language",
      excerpt: "most secure",
      explanation:
        "“Most secure” is not supported by an approved comparison. The source of truth allows the specific audit and encryption statement shown in the security fact.",
      recommendation:
        "Replace the comparative wording with the approved SOC 2 Type II and encryption statement.",
      originalText: "most secure solution",
      suggestedText: null,
      sourceId: sourceId("security"),
      sourceTitle: "Approved security statement",
      sourceLabel: "Meridian brand handbook · 2026",
      confidence: 0.94,
    },
    {
      id: `${userId}:seed:finding-tone`,
      severity: "pass",
      category: "Voice & CTA",
      title: "Tone and call to action align",
      excerpt: "“Learn more today.”",
      explanation:
        "The closing line is direct, friendly, and consistent with the campaign voice guide.",
      recommendation: "No change needed.",
      originalText: null,
      suggestedText: null,
      sourceId: sourceId("voice"),
      sourceTitle: "Voice & tone",
      sourceLabel: "Meridian brand handbook · 2026",
      confidence: 0.92,
    },
  ]

  return {
    id: `${userId}:seed:launch-review`,
    userId,
    title: "Sample · Meridian product launch",
    channel: "Landing page",
    draft:
      "Our new platform is the fastest and most secure solution for every team.\n\nLearn more today.",
    status: "needs_review" as const,
    score: 64,
    summary:
      "Two claims need approved wording before this draft is ready to publish. The voice and call to action are on-brand.",
    findings,
    attachment: {},
  }
}

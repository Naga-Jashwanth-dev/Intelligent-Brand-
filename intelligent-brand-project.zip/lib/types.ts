export type SourceKind = "guideline" | "fact" | "terminology" | "asset"
export type SourceStatus = "approved" | "draft" | "archived"
export type ReviewStatus = "needs_review" | "ready" | "approved" | "changes_requested"
export type FindingSeverity = "high" | "medium" | "low" | "pass"

export interface ReviewFinding {
  id: string
  severity: FindingSeverity
  category: string
  title: string
  excerpt: string
  explanation: string
  recommendation: string
  originalText: string | null
  suggestedText: string | null
  sourceId: string | null
  sourceTitle: string | null
  sourceLabel: string | null
  confidence: number
}

export interface ReviewAttachment {
  name: string
  kind: "image" | "pdf" | "document" | "text"
  mediaType: string
  size: number
  altText: string
}

export interface BrandSource {
  id: string
  kind: SourceKind
  title: string
  body: string
  status: SourceStatus
  sourceLabel: string | null
  sourceUrl: string | null
  metadata: Record<string, unknown>
  createdAt: string
  updatedAt: string
}

export interface BrandReview {
  id: string
  title: string
  channel: string
  draft: string
  status: ReviewStatus
  score: number
  summary: string
  findings: ReviewFinding[]
  attachment: ReviewAttachment | null
  createdAt: string
  updatedAt: string
}

export interface ReviewEvent {
  id: string
  reviewId: string
  event: string
  actor: string
  details: Record<string, unknown>
  createdAt: string
}

export interface WorkspaceData {
  sources: BrandSource[]
  reviews: BrandReview[]
  events: ReviewEvent[]
}

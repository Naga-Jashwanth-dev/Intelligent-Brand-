import "server-only"
import { and, desc, eq } from "drizzle-orm"
import { db } from "@/lib/db"
import { createDemoReview, createDemoSources } from "@/lib/brand-seeds"
import { brandReviews, brandSources, reviewEvents } from "@/lib/schema"
import type { BrandReview, BrandSource, ReviewAttachment, ReviewEvent, WorkspaceData } from "@/lib/types"

function asIso(value: Date) {
  return value instanceof Date ? value.toISOString() : new Date(value).toISOString()
}

export function serializeSource(row: typeof brandSources.$inferSelect): BrandSource {
  return {
    id: row.id,
    kind: row.kind,
    title: row.title,
    body: row.body,
    status: row.status,
    sourceLabel: row.sourceLabel,
    sourceUrl: row.sourceUrl,
    metadata: row.metadata ?? {},
    createdAt: asIso(row.createdAt),
    updatedAt: asIso(row.updatedAt),
  }
}

export function serializeReview(row: typeof brandReviews.$inferSelect): BrandReview {
  const candidate = row.attachment as Partial<ReviewAttachment> | null
  const attachment = candidate?.name
    ? {
        name: String(candidate.name),
        kind: candidate.kind ?? "document",
        mediaType: String(candidate.mediaType ?? "application/octet-stream"),
        size: Number(candidate.size ?? 0),
        altText: String(candidate.altText ?? ""),
      }
    : null

  return {
    id: row.id,
    title: row.title,
    channel: row.channel,
    draft: row.draft,
    status: row.status,
    score: row.score,
    summary: row.summary,
    findings: Array.isArray(row.findings) ? row.findings : [],
    attachment,
    createdAt: asIso(row.createdAt),
    updatedAt: asIso(row.updatedAt),
  }
}

export function serializeEvent(row: typeof reviewEvents.$inferSelect): ReviewEvent {
  return {
    id: row.id,
    reviewId: row.reviewId,
    event: row.event,
    actor: row.actor,
    details: row.details ?? {},
    createdAt: asIso(row.createdAt),
  }
}

export async function ensureDemoWorkspace(userId: string) {
  const [sourceCheck, reviewCheck] = await Promise.all([
    db
      .select({ id: brandSources.id })
      .from(brandSources)
      .where(eq(brandSources.userId, userId))
      .limit(1),
    db
      .select({ id: brandReviews.id })
      .from(brandReviews)
      .where(eq(brandReviews.userId, userId))
      .limit(1),
  ])

  if (sourceCheck.length === 0) {
    await db.insert(brandSources).values(createDemoSources(userId)).onConflictDoNothing()
  }

  if (reviewCheck.length === 0) {
    const review = createDemoReview(userId)
    await db
      .insert(brandReviews)
      .values({
        ...review,
        attachment: {},
      })
      .onConflictDoNothing()

    await db
      .insert(reviewEvents)
      .values({
        id: `${userId}:seed:event:created`,
        userId,
        reviewId: review.id,
        event: "review_created",
        actor: "Intelligent Brand demo",
        details: { findingCount: review.findings.length, score: review.score },
      })
      .onConflictDoNothing()
  }
}

export async function getWorkspaceData(userId: string): Promise<WorkspaceData> {
  await ensureDemoWorkspace(userId)

  const [sourceRows, reviewRows, eventRows] = await Promise.all([
    db
      .select()
      .from(brandSources)
      .where(eq(brandSources.userId, userId))
      .orderBy(desc(brandSources.updatedAt))
      .limit(100),
    db
      .select()
      .from(brandReviews)
      .where(eq(brandReviews.userId, userId))
      .orderBy(desc(brandReviews.updatedAt))
      .limit(50),
    db
      .select()
      .from(reviewEvents)
      .where(eq(reviewEvents.userId, userId))
      .orderBy(desc(reviewEvents.createdAt))
      .limit(100),
  ])

  return {
    sources: sourceRows.map(serializeSource),
    reviews: reviewRows.map(serializeReview),
    events: eventRows.map(serializeEvent),
  }
}

export async function findOwnedReview(userId: string, reviewId: string) {
  const [row] = await db
    .select()
    .from(brandReviews)
    .where(and(eq(brandReviews.id, reviewId), eq(brandReviews.userId, userId)))
    .limit(1)
  return row ?? null
}

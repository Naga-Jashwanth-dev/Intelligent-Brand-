'use client'

import { useState } from "react"
import { Menu, ShieldCheck, LogOut, LockKeyhole, Plus, Users } from "lucide-react"
import { useRouter } from "next/navigation"
import { authClient } from "@/lib/auth-client"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { BrandSidebar } from "@/components/brand-sidebar"
import { DashboardOverview } from "@/components/dashboard-overview"
import { ReviewQueue } from "@/components/review-queue"
import { ReviewWorkspace } from "@/components/review-workspace"
import { SourceLibrary } from "@/components/source-library"
import { InsightsPanel } from "@/components/insights-panel"
import { getInitials } from "@/components/brand-ui"
import type { BrandReview, BrandSource, ReviewEvent, WorkspaceData } from "@/lib/types"

type AppView = "overview" | "reviews" | "sources" | "insights" | "new-review" | "review-detail"
type SidebarView = "overview" | "reviews" | "sources" | "insights"

export function BrandGuardApp({
  currentUser,
  initialData,
}: {
  currentUser: { name: string; email: string }
  initialData: WorkspaceData
}) {
  const router = useRouter()
  const isDemoAccount = currentUser.email.toLowerCase() === "brandguard-demo@example.com"
  const displayName = isDemoAccount ? "Intelligent Brand Demo" : currentUser.name || currentUser.email
  const greetingName = isDemoAccount ? "Intelligent Brand" : displayName.split(" ")[0] || "there"
  const [activeView, setActiveView] = useState<AppView>("overview")
  const [selectedReviewId, setSelectedReviewId] = useState<string | null>(initialData.reviews[0]?.id ?? null)
  const [reviews, setReviews] = useState(initialData.reviews)
  const [sources, setSources] = useState(initialData.sources)
  const [events, setEvents] = useState(initialData.events)
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [isSigningOut, setIsSigningOut] = useState(false)

  const pendingCount = reviews.filter(
    (review) => review.status === "needs_review" || review.status === "changes_requested",
  ).length
  const selectedReview = reviews.find((review) => review.id === selectedReviewId) ?? null
  const sidebarView: SidebarView = activeView === "new-review" || activeView === "review-detail" ? "reviews" : activeView
  const viewLabels: Record<AppView, string> = {
    overview: "Overview",
    reviews: "Review queue",
    sources: "Source library",
    insights: "Governance insights",
    "new-review": "New review",
    "review-detail": selectedReview?.title ?? "Review details",
  }

  function addLocalEvent(reviewId: string, event: string) {
    const localEvent: ReviewEvent = {
      id: `local-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      reviewId,
      event,
      actor: displayName,
      details: {},
      createdAt: new Date().toISOString(),
    }
    setEvents((previous) => [localEvent, ...previous.filter((item) => item.id !== localEvent.id)])
  }

  function handleReviewSaved(review: BrandReview, event: string) {
    setReviews((previous) => [review, ...previous.filter((item) => item.id !== review.id)].sort(
      (a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt),
    ))
    setSelectedReviewId(review.id)
    setActiveView("review-detail")
    addLocalEvent(review.id, event)
  }

  function handleSourceChanged(source: BrandSource) {
    setSources((previous) => [source, ...previous.filter((item) => item.id !== source.id)].sort(
      (a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt),
    ))
  }

  function navigate(view: SidebarView) {
    setActiveView(view)
    setMobileNavOpen(false)
  }

  async function signOut() {
    setIsSigningOut(true)
    try {
      await authClient.signOut()
    } finally {
      router.replace("/sign-in")
      router.refresh()
      setIsSigningOut(false)
    }
  }

  return (
    <div className="workspace-shell">
      {mobileNavOpen ? (
        <button type="button" className="sidebar-scrim" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />
      ) : null}
      <BrandSidebar
        activeView={sidebarView}
        pendingReviews={pendingCount}
        isOpen={mobileNavOpen}
        isDemoAccount={isDemoAccount}
        onNavigate={navigate}
      />

      <div className="workspace-main">
        <header className="workspace-topbar">
          <div className="topbar-left">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="mobile-nav-trigger"
              aria-label={mobileNavOpen ? "Close navigation" : "Open navigation"}
              onClick={() => setMobileNavOpen((open) => !open)}
            >
              <Menu aria-hidden="true" />
            </Button>
            <div className="topbar-breadcrumb">
              <span>My workspace</span>
              <span className="breadcrumb-separator" aria-hidden="true">/</span>
              <strong>{viewLabels[activeView]}</strong>
            </div>
          </div>
          <div className="topbar-actions">
            <span className="topbar-private">
              {isDemoAccount ? <Users aria-hidden="true" /> : <LockKeyhole aria-hidden="true" />}
              {isDemoAccount ? "Shared demo workspace" : "Private workspace"}
            </span>
            <Button type="button" size="sm" className="topbar-new-review" onClick={() => setActiveView("new-review")}>
              <Plus aria-hidden="true" data-icon="inline-start" /> New review
            </Button>
            <div className="topbar-user">
              <Avatar size="sm" className="topbar-avatar"><AvatarFallback>{getInitials(displayName)}</AvatarFallback></Avatar>
              <span className="topbar-user__name">{displayName}</span>
              <Button type="button" variant="ghost" size="icon-sm" aria-label="Sign out" disabled={isSigningOut} onClick={signOut}>
                <LogOut aria-hidden="true" />
              </Button>
            </div>
          </div>
        </header>

        <main className="workspace-content">
          {activeView === "overview" ? (
            <DashboardOverview
              greetingName={greetingName}
              reviews={reviews}
              sources={sources}
              onNewReview={() => setActiveView("new-review")}
              onOpenReview={(id) => { setSelectedReviewId(id); setActiveView("review-detail"); }}
              onNavigate={navigate}
            />
          ) : null}
          {activeView === "reviews" ? (
            <ReviewQueue
              reviews={reviews}
              onOpenReview={(id) => { setSelectedReviewId(id); setActiveView("review-detail"); }}
              onNewReview={() => setActiveView("new-review")}
            />
          ) : null}
          {activeView === "sources" ? (
            <SourceLibrary sources={sources} onSourceChanged={handleSourceChanged} />
          ) : null}
          {activeView === "insights" ? (
            <InsightsPanel reviews={reviews} sources={sources} />
          ) : null}
          {activeView === "new-review" ? (
            <ReviewWorkspace
              key="new-review"
              review={null}
              sources={sources}
              events={events}
              onSaved={handleReviewSaved}
              onBack={() => setActiveView("reviews")}
              onViewSources={() => setActiveView("sources")}
            />
          ) : null}
          {activeView === "review-detail" && selectedReview ? (
            <ReviewWorkspace
              key={selectedReview.id}
              review={selectedReview}
              sources={sources}
              events={events}
              onSaved={handleReviewSaved}
              onBack={() => setActiveView("reviews")}
              onViewSources={() => setActiveView("sources")}
            />
          ) : null}
          {activeView === "review-detail" && !selectedReview ? (
            <div className="empty-state workspace-empty"><span className="empty-state__icon"><ShieldCheck aria-hidden="true" /></span><h2>Review not found</h2><Button type="button" onClick={() => setActiveView("reviews")}>Return to the review queue</Button></div>
          ) : null}
        </main>
        <footer className="workspace-footer">
          <span><ShieldCheck aria-hidden="true" /> Intelligent Brand</span>
          <span>AI-assisted review · Human-led approval</span>
        </footer>
      </div>
    </div>
  )
}

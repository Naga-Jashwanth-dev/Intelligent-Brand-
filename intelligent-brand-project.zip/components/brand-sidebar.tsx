'use client'

import {
  BarChart3,
  BookOpenCheck,
  FileSearch,
  LayoutDashboard,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react"
import { Button } from "@/components/ui/button"

type SidebarView = "overview" | "reviews" | "sources" | "insights"

const navigation: { id: SidebarView; label: string; icon: LucideIcon }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "reviews", label: "Review queue", icon: FileSearch },
  { id: "sources", label: "Source library", icon: BookOpenCheck },
  { id: "insights", label: "Governance insights", icon: BarChart3 },
]

export function BrandSidebar({
  activeView,
  pendingReviews,
  isOpen,
  isDemoAccount,
  onNavigate,
}: {
  activeView: SidebarView
  pendingReviews: number
  isOpen: boolean
  isDemoAccount: boolean
  onNavigate: (view: SidebarView) => void
}) {
  return (
    <aside
      className={`workspace-sidebar${isOpen ? " is-open" : ""}`}
      aria-label="Main navigation"
    >
      <div className="sidebar-brand">
        <div className="brand-mark" aria-hidden="true">
          <ShieldCheck />
        </div>
        <div>
          <p className="sidebar-brand__name">Intelligent Brand</p>
          <p className="sidebar-brand__tagline">Consistency by design</p>
        </div>
      </div>

      <div className="sidebar-workspace">
        <span className="sidebar-workspace__label">WORKSPACE</span>
        <div className="workspace-switcher">
          <div className="workspace-switcher__monogram">W</div>
          <div className="workspace-switcher__copy">
            <strong>{isDemoAccount ? "Public demo" : "My brand"}</strong>
            <span>{isDemoAccount ? "Shared sample data" : "Private workspace"}</span>
          </div>
          <span
            className="workspace-switcher__dot"
            aria-label={isDemoAccount ? "Shared demo" : "Private"}
          />
        </div>
      </div>

      <nav className="sidebar-nav" aria-label="Workspace sections">
        <span className="sidebar-workspace__label">GOVERNANCE</span>
        {navigation.map(({ id, label, icon: Icon }) => (
          <Button
            key={id}
            type="button"
            variant="ghost"
            className={`sidebar-nav-item${activeView === id ? " is-active" : ""}`}
            aria-current={activeView === id ? "page" : undefined}
            onClick={() => onNavigate(id)}
          >
            <Icon aria-hidden="true" data-icon="inline-start" />
            <span>{label}</span>
            {id === "reviews" && pendingReviews > 0 ? (
              <span className="sidebar-nav-count" aria-label={`${pendingReviews} open reviews`}>
                {pendingReviews}
              </span>
            ) : null}
          </Button>
        ))}
      </nav>

      <div className="sidebar-trust-card">
        <div className="sidebar-trust-card__icon">
          <ShieldCheck aria-hidden="true" />
        </div>
        <p className="sidebar-trust-card__title">Human approval stays in control</p>
        <p className="sidebar-trust-card__copy">
          AI flags and explains. Your team makes the final call.
        </p>
      </div>

      <footer className="sidebar-footer">
        <span className="sidebar-footer__status" />
        <span>
          {isDemoAccount
            ? "Demo data is shared with all visitors"
            : "Workspace data is private to your account"}
        </span>
      </footer>
    </aside>
  )
}

import type { CSSProperties, ReactNode } from "react"
import {
  AlertTriangle,
  CheckCircle2,
  CircleAlert,
  Clock3,
  Info,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { FindingSeverity, ReviewStatus } from "@/lib/types"

const severityLabels: Record<FindingSeverity, string> = {
  high: "High",
  medium: "Medium",
  low: "Low",
  pass: "Pass",
}

const severityIcons: Record<FindingSeverity, LucideIcon> = {
  high: CircleAlert,
  medium: AlertTriangle,
  low: Info,
  pass: CheckCircle2,
}

const statusLabels: Record<ReviewStatus, string> = {
  needs_review: "Needs review",
  ready: "Ready for approval",
  approved: "Approved",
  changes_requested: "Changes requested",
}

const statusIcons: Record<ReviewStatus, LucideIcon> = {
  needs_review: Clock3,
  ready: ShieldCheck,
  approved: CheckCircle2,
  changes_requested: AlertTriangle,
}

export function SeverityBadge({ severity }: { severity: FindingSeverity }) {
  const Icon = severityIcons[severity]
  return (
    <Badge variant="outline" className={`status-chip severity-${severity}`}>
      <Icon aria-hidden="true" />
      {severityLabels[severity]}
    </Badge>
  )
}

export function StatusBadge({ status }: { status: ReviewStatus }) {
  const Icon = statusIcons[status]
  return (
    <Badge variant="outline" className={`status-chip review-status-${status}`}>
      <Icon aria-hidden="true" />
      {statusLabels[status]}
    </Badge>
  )
}

export function PageIntro({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow: string
  title: string
  description: string
  actions?: ReactNode
}) {
  return (
    <header className="page-intro">
      <div className="page-intro__copy">
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="page-intro__description">{description}</p>
      </div>
      {actions ? <div className="page-intro__actions">{actions}</div> : null}
    </header>
  )
}

export function ScoreRing({ score }: { score: number | null }) {
  const normalizedScore = score === null ? 0 : Math.max(0, Math.min(100, score))
  return (
    <div
      className="score-ring"
      role="img"
      aria-label={score === null ? "Brand alignment score pending re-review" : `Brand alignment score ${score} out of 100`}
      style={{ "--score": `${normalizedScore}%` } as CSSProperties}
    >
      <div className="score-ring__inner">
        <strong>{score === null ? "—" : score}</strong>
        <span>score</span>
      </div>
    </div>
  )
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(value))
}

export function formatShortDate(value: Date | string) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(typeof value === "string" ? new Date(value) : value)
}

export function getInitials(value: string) {
  const parts = value.trim().split(/[\s@._-]+/).filter(Boolean)
  return parts
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("") || "BG"
}

export function eventLabel(event: string) {
  const labels: Record<string, string> = {
    review_created: "Review created",
    review_rechecked: "Draft reviewed again",
    suggestion_applied: "Suggestion applied",
    approved: "Approved",
    changes_requested: "Changes requested",
  }
  return labels[event] ?? event.replaceAll("_", " ")
}

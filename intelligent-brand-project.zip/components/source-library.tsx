'use client'

import { useMemo, useState, type FormEvent } from "react"
import { Archive, BookOpenCheck, Check, FilePlus2, Link2, Plus, Search, ShieldCheck } from "lucide-react"
import { createSource, updateSourceStatus } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Field,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldSet,
  FieldLegend,
} from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { PageIntro } from "@/components/brand-ui"
import type { BrandSource, SourceKind, SourceStatus } from "@/lib/types"

const kindOptions: { label: string; value: SourceKind | "all" }[] = [
  { label: "All source types", value: "all" },
  { label: "Guidelines", value: "guideline" },
  { label: "Facts", value: "fact" },
  { label: "Terminology", value: "terminology" },
  { label: "Assets", value: "asset" },
]

const kindLabels: Record<SourceKind, string> = {
  guideline: "Guideline",
  fact: "Approved fact",
  terminology: "Terminology",
  asset: "Asset reference",
}

export function SourceLibrary({
  sources,
  onSourceChanged,
}: {
  sources: BrandSource[]
  onSourceChanged: (source: BrandSource) => void
}) {
  const [isAdding, setIsAdding] = useState(false)
  const [kind, setKind] = useState<SourceKind>("guideline")
  const [title, setTitle] = useState("")
  const [body, setBody] = useState("")
  const [sourceLabel, setSourceLabel] = useState("Workspace source")
  const [sourceUrl, setSourceUrl] = useState("")
  const [query, setQuery] = useState("")
  const [kindFilter, setKindFilter] = useState<SourceKind | "all">("all")
  const [error, setError] = useState("")
  const [notice, setNotice] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [updatingSource, setUpdatingSource] = useState<string | null>(null)

  const filteredSources = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase()
    return sources.filter((source) => {
      const matchesKind = kindFilter === "all" || source.kind === kindFilter
      const matchesQuery = !normalizedQuery || `${source.title} ${source.body} ${source.sourceLabel ?? ""}`.toLowerCase().includes(normalizedQuery)
      return matchesKind && matchesQuery
    })
  }, [kindFilter, query, sources])

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSaving(true)
    setError("")
    setNotice("")
    try {
      const result = await createSource({ kind, title, body, sourceLabel, sourceUrl })
      if (!result.source) {
        setError(result.error ?? "We couldn't save this source.")
        return
      }
      onSourceChanged(result.source)
      setTitle("")
      setBody("")
      setSourceUrl("")
      setSourceLabel("Workspace source")
      setIsAdding(false)
      setNotice("Source saved as a draft. Approve it before AI reviews can cite it.")
    } catch {
      setError("We couldn't save this source. Please try again.")
    } finally {
      setIsSaving(false)
    }
  }

  async function handleStatusChange(source: BrandSource) {
    const nextStatus: SourceStatus = source.status === "draft"
      ? "approved"
      : source.status === "approved"
        ? "archived"
        : "draft"
    setUpdatingSource(source.id)
    setError("")
    setNotice("")
    try {
      const result = await updateSourceStatus(source.id, nextStatus)
      if (!result.source) {
        setError(result.error ?? "We couldn't update this source.")
        return
      }
      onSourceChanged(result.source)
      setNotice(nextStatus === "approved" ? "Source approved and available to future reviews." : nextStatus === "archived" ? "Source archived and excluded from future reviews." : "Source restored as a draft.")
    } catch {
      setError("We couldn't update this source. Please try again.")
    } finally {
      setUpdatingSource(null)
    }
  }

  const approvedCount = sources.filter((source) => source.status === "approved").length
  const draftCount = sources.filter((source) => source.status === "draft").length

  return (
    <div className="page-stack">
      <PageIntro
        eyebrow="APPROVED KNOWLEDGE"
        title="Source library"
        description="Keep the guidance, facts, terms, and asset references that every review should use."
        actions={(
          <Button type="button" size="lg" onClick={() => { setIsAdding((value) => !value); setError(""); }}>
            <Plus aria-hidden="true" data-icon="inline-start" /> {isAdding ? "Close form" : "Add a source"}
          </Button>
        )}
      />

      <div className="source-banner">
        <div className="source-banner__icon"><ShieldCheck aria-hidden="true" /></div>
        <div><strong>Human-approved sources only</strong><p>New entries are saved as drafts. Approve them before the AI review engine can cite them.</p></div>
        <div className="source-banner__counts"><span><strong>{approvedCount}</strong> approved</span><span><strong>{draftCount}</strong> drafts</span></div>
      </div>

      {notice ? <p className="inline-status" role="status"><Check aria-hidden="true" />{notice}</p> : null}
      {error && !isAdding ? <p className="inline-error" role="alert">{error}</p> : null}

      {isAdding ? (
        <Card className="source-form-card">
          <CardHeader className="source-form-card__header">
            <div><p className="section-eyebrow">ADD TO THE SOURCE OF TRUTH</p><CardTitle><h2>New source</h2></CardTitle></div>
            <FilePlus2 aria-hidden="true" />
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              <FieldSet>
                <FieldLegend variant="label">Source details</FieldLegend>
                <FieldDescription>Paste only information your organization is permitted to store in this workspace.</FieldDescription>
                <FieldGroup>
                  <div className="form-grid-two">
                    <Field>
                      <FieldLabel htmlFor="source-kind">Type</FieldLabel>
                      <Select value={kind} onValueChange={(value) => value && setKind(value as SourceKind)}>
                        <SelectTrigger id="source-kind" className="w-full"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {kindOptions.filter((option) => option.value !== "all").map((option) => (
                            <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field>
                      <FieldLabel htmlFor="source-title">Title</FieldLabel>
                      <Input id="source-title" value={title} onChange={(event) => setTitle(event.target.value)} minLength={3} maxLength={100} placeholder="e.g. Product security statement" required />
                    </Field>
                  </div>
                  <Field>
                    <FieldLabel htmlFor="source-body">Approved guidance or fact</FieldLabel>
                    <Textarea id="source-body" className="source-textarea" value={body} onChange={(event) => setBody(event.target.value.slice(0, 6000))} maxLength={6000} minLength={12} rows={5} placeholder="Write the exact approved wording, the conditions for using it, and any important limitations…" required />
                    <FieldDescription>{body.length.toLocaleString()} / 6,000 characters. Include scope, dates, and limitations for factual claims.</FieldDescription>
                  </Field>
                  <div className="form-grid-two">
                    <Field>
                      <FieldLabel htmlFor="source-label">Source label</FieldLabel>
                      <Input id="source-label" value={sourceLabel} onChange={(event) => setSourceLabel(event.target.value)} maxLength={120} placeholder="Brand handbook · 2026" />
                    </Field>
                    <Field>
                      <FieldLabel htmlFor="source-url">Reference URL <span className="optional-label">Optional</span></FieldLabel>
                      <Input id="source-url" type="url" value={sourceUrl} onChange={(event) => setSourceUrl(event.target.value)} maxLength={500} placeholder="https://…" />
                      <FieldDescription>Links are stored as citations; they are not fetched by the app.</FieldDescription>
                    </Field>
                  </div>
                  {error ? <FieldError role="alert">{error}</FieldError> : null}
                  <div className="source-form-actions">
                    <p>AI can cite approved sources only.</p>
                    <Button type="submit" disabled={isSaving || title.trim().length < 3 || body.trim().length < 12}>
                      {isSaving ? "Saving…" : "Save as draft"}
                    </Button>
                  </div>
                </FieldGroup>
              </FieldSet>
            </form>
          </CardContent>
        </Card>
      ) : null}

      <Card className="source-library-card">
        <CardHeader className="source-library-card__header">
          <div><p className="section-eyebrow">{sources.length} TOTAL ENTRIES</p><CardTitle><h2>Approved and draft sources</h2></CardTitle></div>
          <Badge variant="outline"><BookOpenCheck aria-hidden="true" /> {approvedCount} active</Badge>
        </CardHeader>
        <CardContent>
          <div className="source-toolbar">
            <Field className="queue-search-field">
              <FieldLabel className="sr-only" htmlFor="source-search">Search sources</FieldLabel>
              <span className="queue-search-icon"><Search aria-hidden="true" /></span>
              <Input id="source-search" type="search" placeholder="Search title or approved wording" value={query} onChange={(event) => setQuery(event.target.value)} />
            </Field>
            <Select value={kindFilter} onValueChange={(value) => setKindFilter((value as SourceKind | "all" | null) ?? "all")}>
              <SelectTrigger className="source-kind-filter" aria-label="Filter by source type"><SelectValue /></SelectTrigger>
              <SelectContent>
                {kindOptions.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {filteredSources.length ? (
            <div className="source-list">
              {filteredSources.map((source) => (
                <article className="source-row" key={source.id}>
                  <div className={`source-row__icon source-row__icon--${source.kind}`}><BookOpenCheck aria-hidden="true" /></div>
                  <div className="source-row__body">
                    <div className="source-row__heading">
                      <h3>{source.title}</h3>
                      <Badge variant="outline" className={`source-kind-badge source-kind-badge--${source.kind}`}>{kindLabels[source.kind]}</Badge>
                      <Badge variant="outline" className={`source-status-badge source-status-badge--${source.status}`}>{source.status}</Badge>
                    </div>
                    <p>{source.body}</p>
                    <div className="source-row__meta">
                      <span>{source.sourceLabel ?? "Workspace source"}</span>
                      {source.sourceUrl ? <a href={source.sourceUrl} target="_blank" rel="noreferrer"><Link2 aria-hidden="true" /> Open reference</a> : null}
                    </div>
                  </div>
                  <Button type="button" variant="outline" size="sm" disabled={updatingSource === source.id} onClick={() => handleStatusChange(source)}>
                    {updatingSource === source.id ? "Saving…" : source.status === "draft" ? <><Check aria-hidden="true" data-icon="inline-start" /> Approve</> : source.status === "approved" ? <><Archive aria-hidden="true" data-icon="inline-start" /> Archive</> : "Restore draft"}
                  </Button>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state source-empty">
              <span className="empty-state__icon"><BookOpenCheck aria-hidden="true" /></span>
              <h2>No sources match this filter</h2>
              <p>Change the search or add a new approved source to the workspace.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

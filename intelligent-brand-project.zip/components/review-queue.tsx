'use client'

import { useMemo, useState } from "react"
import { ArrowUpRight, FileSearch, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Field, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { PageIntro, StatusBadge, formatDate } from "@/components/brand-ui"
import type { BrandReview, ReviewStatus } from "@/lib/types"

const statusOptions: { label: string; value: "all" | ReviewStatus }[] = [
  { label: "All statuses", value: "all" },
  { label: "Needs review", value: "needs_review" },
  { label: "Ready for approval", value: "ready" },
  { label: "Approved", value: "approved" },
  { label: "Changes requested", value: "changes_requested" },
]

export function ReviewQueue({
  reviews,
  onOpenReview,
  onNewReview,
}: {
  reviews: BrandReview[]
  onOpenReview: (id: string) => void
  onNewReview: () => void
}) {
  const [query, setQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | ReviewStatus>("all")
  const filteredReviews = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase()
    return reviews.filter((review) => {
      const matchesStatus = statusFilter === "all" || review.status === statusFilter
      const matchesQuery =
        !normalizedQuery ||
        `${review.title} ${review.channel} ${review.draft}`.toLowerCase().includes(normalizedQuery)
      return matchesStatus && matchesQuery
    })
  }, [query, reviews, statusFilter])

  return (
    <div className="page-stack">
      <PageIntro
        eyebrow="CONTENT WORKFLOW"
        title="Review queue"
        description="Trace every draft from first check to a human decision."
        actions={<Button type="button" size="lg" onClick={onNewReview}><FileSearch aria-hidden="true" data-icon="inline-start" /> New review</Button>}
      />

      <Card className="queue-card">
        <CardContent className="queue-card__content">
          <div className="queue-toolbar">
            <Field className="queue-search-field">
              <FieldLabel className="sr-only" htmlFor="review-search">Search reviews</FieldLabel>
              <span className="queue-search-icon"><Search aria-hidden="true" /></span>
              <Input
                id="review-search"
                type="search"
                placeholder="Search drafts, channels, or titles"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
            </Field>
            <div className="queue-filter">
              <span className="queue-filter__label">Status</span>
              <Select value={statusFilter} onValueChange={(value) => setStatusFilter((value as "all" | ReviewStatus | null) ?? "all")}>
                <SelectTrigger id="review-status-filter" aria-label="Filter reviews by status" className="queue-filter__trigger">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="queue-summary">
            <span><strong>{filteredReviews.length}</strong> {filteredReviews.length === 1 ? "review" : "reviews"}</span>
            <span>Newest updates first</span>
          </div>

          {filteredReviews.length ? (
            <div className="queue-list">
              {filteredReviews.map((review) => {
                const issueCount = review.findings.filter((finding) => finding.severity !== "pass").length
                return (
                  <button
                    key={review.id}
                    type="button"
                    className="queue-row"
                    onClick={() => onOpenReview(review.id)}
                    aria-label={`Open ${review.title}, ${review.status.replaceAll("_", " ")}`}
                  >
                    <span className="queue-row__icon"><FileSearch aria-hidden="true" /></span>
                    <span className="queue-row__copy">
                      <strong>{review.title}</strong>
                      <span>{review.channel} <i aria-hidden="true">·</i> Updated {formatDate(review.updatedAt)}</span>
                    </span>
                    <span className="queue-row__issue-count">
                      <span className={issueCount ? "issue-count-dot is-active" : "issue-count-dot"} />
                      {issueCount} {issueCount === 1 ? "issue" : "issues"}
                    </span>
                    <StatusBadge status={review.status} />
                    <span className="queue-row__score">{review.summary.startsWith("Draft changed.") ? "—" : review.score}</span>
                    <ArrowUpRight className="queue-row__arrow" aria-hidden="true" />
                  </button>
                )
              })}
            </div>
          ) : (
            <div className="empty-state queue-empty">
              <span className="empty-state__icon"><FileSearch aria-hidden="true" /></span>
              <h2>No reviews match this view</h2>
              <p>Try a different search or status, or start a new content review.</p>
              <Button type="button" variant="outline" onClick={onNewReview}>Start a review</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

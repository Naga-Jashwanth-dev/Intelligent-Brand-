'use client'

import { useState, type FormEvent } from "react"
import {
  ArrowLeft,
  ArrowRight,
  BookOpenCheck,
  Check,
  CheckCircle2,
  CircleAlert,
  FileSearch,
  FileText,
  Image as ImageIcon,
  LoaderCircle,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Upload,
} from "lucide-react"
import { applySuggestion, decideReview } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Field,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
} from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { PageIntro, ScoreRing, SeverityBadge, StatusBadge, eventLabel, formatDate } from "@/components/brand-ui"
import type { BrandReview, BrandSource, ReviewEvent } from "@/lib/types"

const channels = ["Website", "Landing page", "Email", "Social media", "Paid ads", "Product release"]

export function ReviewWorkspace({
  review,
  sources,
  events,
  onSaved,
  onBack,
  onViewSources,
}: {
  review: BrandReview | null
  sources: BrandSource[]
  events: ReviewEvent[]
  onSaved: (review: BrandReview, event: string) => void
  onBack: () => void
  onViewSources: () => void
}) {
  const [title, setTitle] = useState(review?.title ?? "Campaign draft")
  const [channel, setChannel] = useState(review?.channel ?? "Website")
  const [draft, setDraft] = useState(review?.draft ?? "")
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null)
  const [altText, setAltText] = useState(review?.attachment?.altText ?? "")
  const [fileInputVersion, setFileInputVersion] = useState(0)
  const [error, setError] = useState("")
  const [statusMessage, setStatusMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [busyFinding, setBusyFinding] = useState<string | null>(null)
  const [isDeciding, setIsDeciding] = useState(false)

  const approvedSources = sources.filter((source) => source.status === "approved")
  const openIssueCount = review?.findings.filter((finding) => finding.severity !== "pass").length ?? 0
  const needsRerun = Boolean(
    review && review.status === "needs_review" && review.summary.startsWith("Draft changed."),
  )
  const reviewEvents = events
    .filter((event) => event.reviewId === review?.id)
    .slice(0, 5)
  const imageSelected = attachmentFile
    ? /\.(png|jpe?g|webp)$/i.test(attachmentFile.name)
    : false

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError("")
    setStatusMessage("")
    setIsSubmitting(true)

    const formData = new FormData()
    formData.set("title", title.trim())
    formData.set("channel", channel)
    formData.set("draft", draft)
    if (review?.id) formData.set("reviewId", review.id)
    if (attachmentFile) {
      formData.set("attachment", attachmentFile)
      formData.set("altText", altText)
    }

    try {
      const response = await fetch("/api/reviews", { method: "POST", body: formData })
      const result = await response.json()
      if (!response.ok || !result.review) {
        setError(result.error ?? "We couldn't complete the review. Please try again.")
        return
      }

      setDraft(result.review.draft)
      setAttachmentFile(null)
      setAltText("")
      setFileInputVersion((version) => version + 1)
      setStatusMessage(
        result.engine === "ai-assisted"
          ? "AI and policy checks are complete. Review the evidence before deciding."
          : "Policy checks are complete. AI analysis is unavailable, so verify the findings manually.",
      )
      onSaved(result.review, review ? "review_rechecked" : "review_created")
    } catch {
      setError("We couldn't reach the review service. Check your connection and try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  async function handleApplySuggestion(findingId: string) {
    if (!review) return
    setBusyFinding(findingId)
    setError("")
    setStatusMessage("")
    try {
      const result = await applySuggestion(review.id, findingId)
      if (!result.review) {
        setError(result.error ?? "That suggestion couldn't be applied.")
        return
      }
      setDraft(result.review.draft)
      setStatusMessage("Suggestion applied. Run the review again to refresh findings and the score.")
      onSaved(result.review, "suggestion_applied")
    } catch {
      setError("That suggestion couldn't be applied. Please retry.")
    } finally {
      setBusyFinding(null)
    }
  }

  async function handleDecision(decision: "approved" | "changes_requested") {
    if (!review) return
    setIsDeciding(true)
    setError("")
    setStatusMessage("")
    try {
      const result = await decideReview(review.id, decision)
      if (!result.review) {
        setError(result.error ?? "We couldn't save that decision.")
        return
      }
      setStatusMessage(decision === "approved" ? "Human approval saved to the audit trail." : "Change request saved to the audit trail.")
      onSaved(result.review, decision)
    } catch {
      setError("We couldn't save that decision. Please retry.")
    } finally {
      setIsDeciding(false)
    }
  }

  return (
    <div className="page-stack">
      <PageIntro
        eyebrow={review ? "CONTENT REVIEW" : "NEW CONTENT REVIEW"}
        title={review ? review.title : "Start a content review"}
        description={review ? `${review.channel} · Updated ${formatDate(review.updatedAt)}` : "Add the draft and its channel. Intelligent Brand checks it against approved sources before a human decision."}
        actions={(
          <Button type="button" variant="outline" onClick={onBack}>
            <ArrowLeft aria-hidden="true" data-icon="inline-start" /> Back to reviews
          </Button>
        )}
      />

      <div className="review-workspace-grid">
        <div className="review-editor-column">
          <Card className="editor-card">
            <CardHeader className="editor-card__header">
              <div className="editor-card__title-wrap">
                <span className="editor-step">01</span>
                <div>
                  <p className="section-eyebrow">SUBMISSION</p>
                  <CardTitle><h2>Campaign draft</h2></CardTitle>
                </div>
              </div>
              <Badge variant="outline" className="private-badge"><ShieldCheck aria-hidden="true" /> Private</Badge>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="review-form">
                <FieldGroup>
                  <div className="form-grid-two">
                    <Field>
                      <FieldLabel htmlFor="review-title">Review title</FieldLabel>
                      <Input
                        id="review-title"
                        name="title"
                        value={title}
                        onChange={(event) => setTitle(event.target.value)}
                        minLength={3}
                        maxLength={120}
                        required
                      />
                    </Field>
                    <Field>
                      <FieldLabel htmlFor="review-channel">Channel</FieldLabel>
                      <Select value={channel} onValueChange={(value) => value && setChannel(value)}>
                        <SelectTrigger id="review-channel" className="w-full" aria-label="Content channel">
                          <SelectValue placeholder="Choose a channel" />
                        </SelectTrigger>
                        <SelectContent>
                          {channels.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </Field>
                  </div>

                  <Field>
                    <div className="draft-field-heading">
                      <FieldLabel htmlFor="review-draft">Draft content</FieldLabel>
                      <span className="character-count">{draft.length.toLocaleString()} / 20,000</span>
                    </div>
                    <Textarea
                      id="review-draft"
                      name="draft"
                      className="draft-textarea"
                      value={draft}
                      onChange={(event) => setDraft(event.target.value.slice(0, 20000))}
                      placeholder="Paste the content you want to check against approved brand sources…"
                      minLength={8}
                      maxLength={20000}
                      required
                      rows={10}
                    />
                    <FieldDescription>
                      Include the copy as it will appear. Claims are checked against approved facts only.
                    </FieldDescription>
                  </Field>

                  <div className="attachment-panel">
                    <Field>
                      <FieldLabel htmlFor="review-attachment">Supporting file <span className="optional-label">Optional</span></FieldLabel>
                      <Input
                        key={fileInputVersion}
                        id="review-attachment"
                        name="attachment"
                        type="file"
                        accept=".pdf,.docx,.txt,.md,.png,.jpg,.jpeg,.webp"
                        onChange={(event) => setAttachmentFile(event.target.files?.[0] ?? null)}
                      />
                      <FieldDescription>
                        PDF, DOCX, TXT, Markdown, PNG, JPG, or WEBP · up to 8 MB. Drafts and files are sent to AI Gateway for analysis; only attachment metadata is saved. Avoid credentials or regulated data.
                      </FieldDescription>
                    </Field>
                    {attachmentFile ? (
                      <div className="selected-file">
                        <span className="selected-file__icon">
                          {imageSelected ? <ImageIcon aria-hidden="true" /> : <FileText aria-hidden="true" />}
                        </span>
                        <span className="selected-file__copy"><strong>{attachmentFile.name}</strong><small>{(attachmentFile.size / 1024).toFixed(0)} KB</small></span>
                        <Check aria-hidden="true" className="selected-file__check" />
                      </div>
                    ) : review?.attachment ? (
                      <div className="selected-file">
                        <span className="selected-file__icon"><FileText aria-hidden="true" /></span>
                        <span className="selected-file__copy"><strong>{review.attachment.name}</strong><small>Previously reviewed attachment metadata</small></span>
                      </div>
                    ) : null}
                    {imageSelected ? (
                      <Field>
                        <FieldLabel htmlFor="review-alt-text">Image alt text</FieldLabel>
                        <Input
                          id="review-alt-text"
                          value={altText}
                          onChange={(event) => setAltText(event.target.value.slice(0, 400))}
                          maxLength={400}
                          placeholder="Describe the image for someone who can't see it"
                        />
                        <FieldDescription>Leave blank only if the image is decorative.</FieldDescription>
                      </Field>
                    ) : null}
                  </div>

                  {error ? <FieldError role="alert">{error}</FieldError> : null}
                  {statusMessage ? <p className="inline-status" role="status"><CheckCircle2 aria-hidden="true" />{statusMessage}</p> : null}

                  <div className="review-submit-row">
                    <p><ShieldCheck aria-hidden="true" /> AI recommends; a human reviewer decides.</p>
                    <Button type="submit" size="lg" disabled={isSubmitting || draft.trim().length < 8 || title.trim().length < 3}>
                      {isSubmitting ? <><LoaderCircle className="spinner-icon" aria-hidden="true" /> Checking draft…</> : <><Sparkles aria-hidden="true" data-icon="inline-start" /> {review ? "Run review again" : "Review before publish"} <ArrowRight aria-hidden="true" data-icon="inline-end" /></>}
                    </Button>
                  </div>
                </FieldGroup>
              </form>
            </CardContent>
          </Card>

          <div className="review-source-note">
            <BookOpenCheck aria-hidden="true" />
            <div>
              <strong>{approvedSources.length} approved sources available</strong>
              <p>Draft sources are excluded until a reviewer approves them.</p>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={onViewSources}>View sources <ArrowRight aria-hidden="true" data-icon="inline-end" /></Button>
          </div>
        </div>

        <div className="review-results-column">
          {review ? (
            <ReviewResults
              review={review}
              events={reviewEvents}
              busyFinding={busyFinding}
              isDeciding={isDeciding}
              needsRerun={needsRerun}
              onApplySuggestion={handleApplySuggestion}
              onDecision={handleDecision}
            />
          ) : (
            <Card className="review-placeholder-card">
              <CardContent className="review-placeholder-card__content">
                <div className="review-placeholder-graphic" aria-hidden="true">
                  <span><FileSearch /></span><i /><span><ShieldCheck /></span>
                </div>
                <p className="section-eyebrow">02 · EXPLAIN</p>
                <h2>Findings with receipts.</h2>
                <p>Run the review to see severity, plain-language reasons, and the approved source behind each flag.</p>
                <div className="placeholder-steps">
                  <span><CheckCircle2 aria-hidden="true" /> Claims & evidence</span>
                  <span><CheckCircle2 aria-hidden="true" /> Terminology & tone</span>
                  <span><CheckCircle2 aria-hidden="true" /> Accessibility & assets</span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

function ReviewResults({
  review,
  events,
  busyFinding,
  isDeciding,
  needsRerun,
  onApplySuggestion,
  onDecision,
}: {
  review: BrandReview
  events: ReviewEvent[]
  busyFinding: string | null
  isDeciding: boolean
  needsRerun: boolean
  onApplySuggestion: (findingId: string) => void
  onDecision: (decision: "approved" | "changes_requested") => void
}) {
  const issueCount = review.findings.filter((finding) => finding.severity !== "pass").length
  const suggestedCount = review.findings.filter((finding) => finding.suggestedText).length

  return (
    <div className="results-stack">
      <Card className="results-summary-card">
        <CardContent className="results-summary-card__content">
          <div className="results-summary-card__top">
            <div>
              <p className="section-eyebrow">03 · REVIEW RESULT</p>
              <h2>{needsRerun ? "Draft changed" : issueCount ? `${issueCount} issue${issueCount === 1 ? "" : "s"} to review` : "Ready for approval"}</h2>
              <p className="results-summary-copy">{review.summary}</p>
            </div>
            <ScoreRing score={needsRerun ? null : review.score} />
          </div>
          <div className="results-summary-meta">
            <StatusBadge status={review.status} />
            <span><CircleAlert aria-hidden="true" /> {issueCount} findings</span>
            <span><Sparkles aria-hidden="true" /> {suggestedCount} suggestions</span>
          </div>
          {needsRerun ? (
            <div className="needs-rerun-note" role="status">
              <RotateCcw aria-hidden="true" /> The current score is paused until you run the review again.
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card className="findings-card">
        <CardHeader className="findings-card__header">
          <div>
            <p className="section-eyebrow">EVIDENCE & ACTION</p>
            <CardTitle><h2>Review findings</h2></CardTitle>
          </div>
          <Badge variant="outline" className="findings-count">{review.findings.length} checks</Badge>
        </CardHeader>
        <CardContent>
          {needsRerun ? (
            <div className="empty-state compact-empty">
              <RotateCcw aria-hidden="true" />
              <p>Run the review again to refresh the findings for this draft version.</p>
            </div>
          ) : review.findings.length ? (
            <div className="finding-list">
              {review.findings.map((finding) => (
                <article className={`finding-card finding-card--${finding.severity}`} key={finding.id}>
                  <div className="finding-card__top">
                    <div className="finding-card__heading">
                      <SeverityBadge severity={finding.severity} />
                      <span className="finding-category">{finding.category}</span>
                    </div>
                    <span className="confidence-label">{Math.round(finding.confidence * 100)}% confidence</span>
                  </div>
                  <h3>{finding.title}</h3>
                  {finding.excerpt ? <blockquote className="finding-excerpt">“{finding.excerpt}”</blockquote> : null}
                  <p className="finding-explanation">{finding.explanation}</p>
                  <div className="finding-recommendation">
                    <span className="recommendation-label">RECOMMENDED ACTION</span>
                    <p>{finding.recommendation}</p>
                  </div>
                  {finding.sourceTitle ? (
                    <div className="finding-source">
                      <BookOpenCheck aria-hidden="true" />
                      <span><small>{finding.sourceLabel ?? "Approved source"}</small><strong>{finding.sourceTitle}</strong></span>
                    </div>
                  ) : (
                    <div className="finding-source finding-source--missing">
                      <CircleAlert aria-hidden="true" />
                      <span><small>Evidence gap</small><strong>No approved source matched this claim.</strong></span>
                    </div>
                  )}
                  {finding.suggestedText ? (
                    <div className="suggestion-box">
                      <div className="suggestion-box__label"><Sparkles aria-hidden="true" /> SUGGESTED CORRECTION</div>
                      <p>{finding.suggestedText}</p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        disabled={busyFinding === finding.id}
                        onClick={() => onApplySuggestion(finding.id)}
                      >
                        {busyFinding === finding.id ? "Applying…" : "Apply to draft"}
                        {busyFinding !== finding.id ? <ArrowRight aria-hidden="true" data-icon="inline-end" /> : null}
                      </Button>
                    </div>
                  ) : null}
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state compact-empty">
              <CheckCircle2 aria-hidden="true" />
              <p>No findings were recorded. A human approval is still required before publishing.</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="decision-card">
        <CardContent className="decision-card__content">
          <div className="decision-copy">
            <p className="section-eyebrow">04 · HUMAN DECISION</p>
            <h2>{review.status === "approved" ? "Decision recorded" : "You own the final call."}</h2>
            <p>
              {review.status === "approved"
                ? "This approval is recorded in the review audit trail. Re-run the review after editing the draft."
                : "AI suggestions are advisory. Confirm the evidence and log an approval or request changes."}
            </p>
          </div>
          {review.status === "approved" ? (
            <Badge variant="outline" className="status-chip review-status-approved"><CheckCircle2 aria-hidden="true" /> Approved</Badge>
          ) : (
            <div className="decision-actions">
              {issueCount > 0 ? <p className="decision-warning"><CircleAlert aria-hidden="true" /> {issueCount} open finding{issueCount === 1 ? "" : "s"}</p> : null}
              <Button
                type="button"
                variant="outline"
                disabled={isDeciding}
                onClick={() => onDecision("changes_requested")}
              >
                Request changes
              </Button>
              <Button
                type="button"
                disabled={isDeciding || needsRerun}
                onClick={() => onDecision("approved")}
              >
                <Check aria-hidden="true" data-icon="inline-start" />
                {isDeciding ? "Saving…" : issueCount ? "Approve with findings" : "Approve draft"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="audit-card">
        <CardHeader className="audit-card__header">
          <div>
            <p className="section-eyebrow">TRACEABILITY</p>
            <CardTitle><h2>Review activity</h2></CardTitle>
          </div>
          <ShieldCheck aria-hidden="true" />
        </CardHeader>
        <CardContent>
          {events.length ? (
            <ol className="audit-list">
              {events.map((event) => (
                <li key={event.id}>
                  <span className={`audit-dot audit-dot--${event.event}`} />
                  <div><strong>{eventLabel(event.event)}</strong><span>{event.actor}</span></div>
                  <time dateTime={event.createdAt}>{formatDate(event.createdAt)}</time>
                </li>
              ))}
            </ol>
          ) : (
            <p className="audit-empty">Review creation, suggestions, and decisions will appear here.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

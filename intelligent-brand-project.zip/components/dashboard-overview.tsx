import {
  ArrowRight,
  BadgeCheck,
  BookOpenCheck,
  CircleAlert,
  ClipboardCheck,
  FileSearch,
  Info,
  ShieldCheck,
  Sparkles,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { PageIntro, StatusBadge, formatDate } from "@/components/brand-ui"
import type { BrandReview, BrandSource } from "@/lib/types"

export function DashboardOverview({
  greetingName,
  reviews,
  sources,
  onNewReview,
  onOpenReview,
  onNavigate,
}: {
  greetingName: string
  reviews: BrandReview[]
  sources: BrandSource[]
  onNewReview: () => void
  onOpenReview: (id: string) => void
  onNavigate: (view: "reviews" | "sources" | "insights") => void
}) {
  const unresolvedCount = reviews.filter(
    (review) => review.status === "needs_review" || review.status === "changes_requested",
  ).length
  const approvedCount = reviews.filter((review) => review.status === "approved").length
  const scoredReviews = reviews.filter(
    (review) => review.score > 0 && !review.summary.startsWith("Draft changed."),
  )
  const averageScore = scoredReviews.length
    ? Math.round(scoredReviews.reduce((sum, review) => sum + review.score, 0) / scoredReviews.length)
    : null
  const approvedSources = sources.filter((source) => source.status === "approved")
  const issues = reviews.flatMap((review) => review.findings.filter((finding) => finding.severity !== "pass"))
  const citedIssues = issues.filter((finding) => finding.sourceId).length
  const citationCoverage = issues.length ? Math.round((citedIssues / issues.length) * 100) : 100
  const latestReviews = reviews.slice(0, 4)

  return (
    <div className="page-stack">
      <PageIntro
        eyebrow="WORKSPACE OVERVIEW"
        title={`Welcome back, ${greetingName || "there"}.`}
        description="A clear view of what needs attention before your next publish."
        actions={(
          <Button type="button" size="lg" onClick={onNewReview}>
            <Sparkles aria-hidden="true" data-icon="inline-start" />
            New content review
          </Button>
        )}
      />

      <section className="hero-card" aria-labelledby="hero-title">
        <div className="hero-card__copy">
          <Badge variant="outline" className="hero-kicker"><ShieldCheck aria-hidden="true" /> BEFORE YOU PUBLISH</Badge>
          <h2 id="hero-title">Consistency by design.<br /><em>Confidence before publish.</em></h2>
          <p>
            Compare campaign drafts with the approved source of truth. Fix issues while the content is still in your hands.
          </p>
          <Button type="button" variant="secondary" size="lg" onClick={onNewReview}>
            Start a review <ArrowRight aria-hidden="true" data-icon="inline-end" />
          </Button>
        </div>
        <div className="hero-visual" aria-hidden="true">
          <div className="hero-visual__orbit hero-visual__orbit--outer" />
          <div className="hero-visual__orbit hero-visual__orbit--inner" />
          <div className="hero-visual__center"><ShieldCheck /></div>
          <span className="hero-visual__node hero-visual__node--one"><BookOpenCheck /></span>
          <span className="hero-visual__node hero-visual__node--two"><FileSearch /></span>
          <span className="hero-visual__node hero-visual__node--three"><BadgeCheck /></span>
          <div className="hero-visual__label hero-visual__label--top">Approved sources</div>
          <div className="hero-visual__label hero-visual__label--bottom">Human decision</div>
        </div>
      </section>

      <section className="metric-grid" aria-label="Workspace metrics">
        <MetricCard
          label="Needs attention"
          value={unresolvedCount.toString().padStart(2, "0")}
          note="Open reviews"
          icon={CircleAlert}
          tone="amber"
        />
        <MetricCard
          label="Brand alignment"
          value={averageScore === null ? "—" : `${averageScore}`}
          note={averageScore === null ? "Scores appear after review" : "Average review score"}
          icon={ShieldCheck}
          tone="green"
        />
        <MetricCard
          label="Human approved"
          value={approvedCount.toString().padStart(2, "0")}
          note="Final decisions logged"
          icon={ClipboardCheck}
          tone="blue"
        />
        <MetricCard
          label="Source coverage"
          value={`${citationCoverage}%`}
          note={`${approvedSources.length} approved sources`}
          icon={BookOpenCheck}
          tone="violet"
        />
      </section>

      <div className="dashboard-grid">
        <Card className="dashboard-card recent-card">
          <CardHeader className="dashboard-card__header">
            <div>
              <p className="section-eyebrow">YOUR CONTENT</p>
              <CardTitle><h2>Recent reviews</h2></CardTitle>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={() => onNavigate("reviews")}>
              View queue <ArrowRight aria-hidden="true" data-icon="inline-end" />
            </Button>
          </CardHeader>
          <CardContent>
            {latestReviews.length ? (
              <div className="recent-review-list">
                {latestReviews.map((review) => (
                  <button
                    type="button"
                    key={review.id}
                    className="recent-review-row"
                    onClick={() => onOpenReview(review.id)}
                  >
                    <span className="review-file-icon"><FileSearch aria-hidden="true" /></span>
                    <span className="recent-review-row__main">
                      <strong>{review.title}</strong>
                      <span>{review.channel} <i aria-hidden="true">·</i> Updated {formatDate(review.updatedAt)}</span>
                    </span>
                    <span className="recent-review-row__meta">
                      <StatusBadge status={review.status} />
                      <span className="row-score">{review.summary.startsWith("Draft changed.") ? "—" : `${review.score}`}</span>
                    </span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="empty-state compact-empty">
                <FileSearch aria-hidden="true" />
                <p>No reviews yet. Start with a campaign draft.</p>
                <Button type="button" variant="outline" size="sm" onClick={onNewReview}>Create first review</Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="dashboard-card sources-snapshot-card">
          <CardHeader className="dashboard-card__header">
            <div>
              <p className="section-eyebrow">SOURCE OF TRUTH</p>
              <CardTitle><h2>Approved knowledge</h2></CardTitle>
            </div>
            <span className="source-total">{approvedSources.length}</span>
          </CardHeader>
          <CardContent>
            <p className="snapshot-description">
              Only approved facts and guidance can support AI citations.
            </p>
            <div className="source-kind-list">
              {([
                ["guideline", "Guidelines"],
                ["fact", "Approved facts"],
                ["terminology", "Terminology"],
                ["asset", "Assets & references"],
              ] as const).map(([kind, label]) => (
                <div className="source-kind-row" key={kind}>
                  <span className={`source-kind-dot source-kind-dot--${kind}`} />
                  <span>{label}</span>
                  <strong>{approvedSources.filter((source) => source.kind === kind).length}</strong>
                </div>
              ))}
            </div>
            <Button type="button" variant="outline" className="snapshot-link" onClick={() => onNavigate("sources")}>
              Manage source library <ArrowRight aria-hidden="true" data-icon="inline-end" />
            </Button>
          </CardContent>
        </Card>
      </div>

      <section className="checks-section">
        <div className="checks-section__heading">
          <div>
            <p className="section-eyebrow">THE REVIEW LAYER</p>
            <h2>One pass. Four kinds of confidence.</h2>
          </div>
          <p>Explainable checks help creators move fast without guessing.</p>
        </div>
        <div className="checks-grid">
          <CheckCard number="01" title="Claims & facts" text="Every measurable claim is checked against approved facts." icon={ShieldCheck} />
          <CheckCard number="02" title="Voice & terms" text="Tone, product names, and preferred language stay consistent." icon={Sparkles} />
          <CheckCard number="03" title="Assets & access" text="Retired marks and missing image context are surfaced early." icon={BookOpenCheck} />
          <CheckCard number="04" title="Human decision" text="Reviewers can approve, request changes, and leave an audit trail." icon={ClipboardCheck} />
        </div>
      </section>

      <p className="demo-note">
        <Info aria-hidden="true" /> Starter workspace includes clearly labeled Meridian sample content. Replace it with your own approved sources.
      </p>
    </div>
  )
}

function MetricCard({
  label,
  value,
  note,
  icon: Icon,
  tone,
}: {
  label: string
  value: string
  note: string
  icon: typeof ShieldCheck
  tone: string
}) {
  return (
    <Card className="metric-card">
      <CardContent className="metric-card__content">
        <div className="metric-card__top">
          <span>{label}</span>
          <span className={`metric-icon metric-icon--${tone}`}><Icon aria-hidden="true" /></span>
        </div>
        <strong className="metric-value">{value}</strong>
        <span className="metric-note">{note}</span>
      </CardContent>
    </Card>
  )
}

function CheckCard({
  number,
  title,
  text,
  icon: Icon,
}: {
  number: string
  title: string
  text: string
  icon: typeof ShieldCheck
}) {
  return (
    <article className="check-card">
      <div className="check-card__top"><span>{number}</span><Icon aria-hidden="true" /></div>
      <h3>{title}</h3>
      <p>{text}</p>
    </article>
  )
}

'use client'

import { useMemo } from "react"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { ArrowUpRight, BadgeCheck, BookOpenCheck, CircleAlert, ShieldCheck } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { PageIntro, formatShortDate } from "@/components/brand-ui"
import type { BrandReview, BrandSource, FindingSeverity } from "@/lib/types"

const chartConfig = {
  reviews: { label: "Reviews", color: "var(--chart-1)" },
  approved: { label: "Approved", color: "var(--chart-2)" },
} satisfies ChartConfig

const severityLabels: Record<FindingSeverity, string> = {
  high: "High severity",
  medium: "Medium severity",
  low: "Low severity",
  pass: "Pass checks",
}

export function InsightsPanel({ reviews, sources }: { reviews: BrandReview[]; sources: BrandSource[] }) {
  const metrics = useMemo(() => {
    const finalDecisions = reviews.filter((review) => review.status === "approved" || review.status === "changes_requested")
    const scoreable = reviews.filter((review) => review.score > 0 && !review.summary.startsWith("Draft changed."))
    const findings = reviews.flatMap((review) => review.findings.filter((finding) => finding.severity !== "pass"))
    const citedFindings = findings.filter((finding) => finding.sourceId).length
    const issueGroups = new Map<string, { count: number; severity: FindingSeverity }>()

    for (const finding of findings) {
      const current = issueGroups.get(finding.category)
      issueGroups.set(finding.category, {
        count: (current?.count ?? 0) + 1,
        severity: current?.severity === "high" || finding.severity === "high"
          ? "high"
          : current?.severity === "medium" || finding.severity === "medium"
            ? "medium"
            : finding.severity,
      })
    }

    const sortedReviews = [...reviews].sort((a, b) => Date.parse(a.createdAt) - Date.parse(b.createdAt))
    const anchor = sortedReviews.length ? new Date(sortedReviews[sortedReviews.length - 1].createdAt) : new Date("2026-01-01T00:00:00.000Z")
    const anchorStart = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth(), anchor.getUTCDate()))
    const dayOfWeek = anchorStart.getUTCDay()
    anchorStart.setUTCDate(anchorStart.getUTCDate() - dayOfWeek)
    const activity = Array.from({ length: 6 }, (_, index) => {
      const weekStart = new Date(anchorStart)
      weekStart.setUTCDate(anchorStart.getUTCDate() - (5 - index) * 7)
      const weekEnd = new Date(weekStart)
      weekEnd.setUTCDate(weekStart.getUTCDate() + 7)
      const inWeek = reviews.filter((review) => {
        const created = Date.parse(review.createdAt)
        return created >= weekStart.getTime() && created < weekEnd.getTime()
      })
      return {
        week: formatShortDate(weekStart),
        reviews: inWeek.length,
        approved: inWeek.filter((review) => review.status === "approved").length,
      }
    })

    return {
      reviewCount: reviews.length,
      approvalRate: finalDecisions.length ? Math.round((finalDecisions.filter((review) => review.status === "approved").length / finalDecisions.length) * 100) : null,
      averageScore: scoreable.length ? Math.round(scoreable.reduce((sum, review) => sum + review.score, 0) / scoreable.length) : null,
      citationCoverage: findings.length ? Math.round((citedFindings / findings.length) * 100) : 100,
      findingCount: findings.length,
      issueGroups: [...issueGroups.entries()].map(([category, value]) => ({ category, ...value })).sort((a, b) => b.count - a.count).slice(0, 6),
      activity,
    }
  }, [reviews])

  const approvedSources = sources.filter((source) => source.status === "approved").length
  const maxIssueCount = Math.max(1, ...metrics.issueGroups.map((item) => item.count))

  return (
    <div className="page-stack">
      <PageIntro
        eyebrow="GOVERNANCE SIGNALS"
        title="Insights that improve the next draft."
        description="Use your own review history to spot recurring issues and source gaps."
      />

      <section className="metric-grid insight-metrics" aria-label="Governance metrics">
        <InsightMetric label="Reviewed drafts" value={metrics.reviewCount.toString()} note="All saved reviews" icon={BookOpenCheck} tone="green" />
        <InsightMetric label="Human approval rate" value={metrics.approvalRate === null ? "—" : `${metrics.approvalRate}%`} note="Of final decisions" icon={BadgeCheck} tone="blue" />
        <InsightMetric label="Average alignment" value={metrics.averageScore === null ? "—" : `${metrics.averageScore}`} note="Across scored drafts" icon={ShieldCheck} tone="violet" />
        <InsightMetric label="Evidence coverage" value={`${metrics.citationCoverage}%`} note={`${approvedSources} approved sources`} icon={CircleAlert} tone="amber" />
      </section>

      <div className="insights-grid">
        <Card className="insight-chart-card">
          <CardHeader className="dashboard-card__header">
            <div><p className="section-eyebrow">ACTIVITY</p><CardTitle><h2>Review momentum</h2></CardTitle></div>
            <Badge variant="outline">Last 6 weeks</Badge>
          </CardHeader>
          <CardContent>
            {metrics.reviewCount ? (
              <ChartContainer config={chartConfig} className="insight-chart">
                <BarChart accessibilityLayer data={metrics.activity} margin={{ top: 8, right: 12, bottom: 4, left: -18 }}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" />
                  <XAxis dataKey="week" tickLine={false} axisLine={false} tickMargin={8} />
                  <YAxis allowDecimals={false} tickLine={false} axisLine={false} width={28} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="reviews" fill="var(--color-reviews)" radius={[5, 5, 0, 0]} />
                  <Bar dataKey="approved" fill="var(--color-approved)" radius={[5, 5, 0, 0]} />
                </BarChart>
              </ChartContainer>
            ) : (
              <div className="empty-state compact-empty"><BookOpenCheck aria-hidden="true" /><p>Review activity will appear here after your first submission.</p></div>
            )}
            <div className="chart-legend">
              <span><i className="chart-legend__dot chart-legend__dot--reviews" /> Reviews</span>
              <span><i className="chart-legend__dot chart-legend__dot--approved" /> Approved</span>
            </div>
          </CardContent>
        </Card>

        <Card className="issue-trends-card">
          <CardHeader className="dashboard-card__header">
            <div><p className="section-eyebrow">RECURRING PATTERNS</p><CardTitle><h2>Where drafts get stuck</h2></CardTitle></div>
            <ArrowUpRight aria-hidden="true" />
          </CardHeader>
          <CardContent>
            {metrics.issueGroups.length ? (
              <div className="issue-trend-list">
                {metrics.issueGroups.map((item) => (
                  <div className="issue-trend-row" key={item.category}>
                    <div className="issue-trend-row__head"><span>{item.category}</span><strong>{item.count}</strong></div>
                    <div className="issue-trend-track"><span className={`issue-trend-fill severity-fill--${item.severity}`} style={{ width: `${Math.max(8, (item.count / maxIssueCount) * 100)}%` }} /></div>
                    <span className="issue-trend-row__label">{severityLabels[item.severity]}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state compact-empty"><ShieldCheck aria-hidden="true" /><p>No open findings in the saved review set.</p></div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="insight-note-card">
        <CardContent className="insight-note-card__content">
          <div className="insight-note-card__icon"><ShieldCheck aria-hidden="true" /></div>
          <div><p className="section-eyebrow">INTERPRET WITH CARE</p><h2>Recommendations are signals, not policy decisions.</h2><p>These measures summarize saved reviews in your private workspace. They are not external benchmarks. Human reviewers remain accountable for approvals.</p></div>
        </CardContent>
      </Card>
    </div>
  )
}

function InsightMetric({
  label,
  value,
  note,
  icon: Icon,
  tone,
}: {
  label: string
  value: string
  note: string
  icon: typeof ShieldCheck
  tone: string
}) {
  return (
    <Card className="metric-card">
      <CardContent className="metric-card__content">
        <div className="metric-card__top"><span>{label}</span><span className={`metric-icon metric-icon--${tone}`}><Icon aria-hidden="true" /></span></div>
        <strong className="metric-value">{value}</strong>
        <span className="metric-note">{note}</span>
      </CardContent>
    </Card>
  )
}
